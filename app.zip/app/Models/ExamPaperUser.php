<?php

namespace App\Models;

class ExamPaperUser extends _BaseModel
{
    protected const UPDATED_AT = null;
}
