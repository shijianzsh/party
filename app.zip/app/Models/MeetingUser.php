<?php

namespace App\Models;

class MeetingUser extends _BaseModel
{

}
