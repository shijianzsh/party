<?php

namespace App\Models;

class PortalCategoryPost extends _BaseModel
{
    protected $fillable = ['category_id','post_id'];
}
