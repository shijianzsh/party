<?php

namespace App\Models;

class UserRole extends _BaseModel
{
    //TODO
}
